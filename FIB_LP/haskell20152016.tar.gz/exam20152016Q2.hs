--allprimes :: [Int]
--allprimes = criba [2..]
-- where criba (x:xs) = x:criba [y | y <- xs, mod y x /= 0]

allsets :: a -> [[a]]
allsets x = iterate (x:) [] 


alldivisors:: Int -> [[Int]]
alldivisors 0 = []
alldivisors 1 = [] 
alldivisors x = filter (/=[]) (map (divider x) candidates) 
 where candidates = takeWhile (<=x)  [2..x]

divider:: Int->Int-> [Int]
divider x div 
 |mod x div == 0 = div:(divider (quot x div) div)
 |otherwise = []


data Expr a = Var String | Const a|
     Func String [Expr a] deriving Show

--let x = Func "op2" [Func "op1" [Const 1,Var "x1"],Var "ma",Func "op4" [Var "x2",Func "op1" [Const 1,Var "x1"]]]
constLeafs :: Expr a -> [a]
constLeafs (Const a) = [a]
constLeafs (Var _ )  = []
constLeafs (Func _ []) = []
constLeafs (Func _ (x:xs)) = constLeafs x ++ (foldr (++) [] ( map constLeafs xs) )   

instance Functor Expr where
 fmap g (Var x) = Var x 
 fmap g (Const x) = (Const $ g x)
 fmap g (Func x list)= (Func x (map (fmap g) list))



join :: Eq a => [(String,a)] -> [(String,a)] -> Maybe [(String,a)]
join xs ys = if( and [null $ filter (fool k )  ys |k <- xs])
 then Just (unsafejoin xs ys)
 else Nothing

--devuelve true si son dos tuplas incompatibles
fool::Eq a =>(String, a)-> (String,a) -> Bool
fool  (x,xc) (y, yc)= (x==y) && (xc/= yc)
 

unsafejoin :: Eq a => [(String,a)] -> [(String,a)] -> [(String,a)]
unsafejoin [] [] = []
unsafejoin x [] = x
unsafejoin [] x = x
unsafejoin (x:xs) (y:ys)
 |fst x < fst y = x: unsafejoin xs (y:ys)
 |fst x > fst y = y : unsafejoin (x:xs) ys
 | otherwise = x : unsafejoin xs ys
 
 
--match:: Eq a => Expr a -> Expr a -> Maybe [(String,(Expr a))]
--match x (Func y list)
-- |numvar x == 1 = domatch x [y]
--match x y
-- |numvar x == 1 = domatch x y
-- |otherwise = Nothing

--numvar:: Expr a -> Bool
--numvar (Var _) = 1
--numvar (Const _) = 0
--numvar (Func _ list) = map numvar list

--size 
--domatch:: Eq a => Expr a -> Expr a -> Maybe [(String,(Expr a))]
--domatch 
