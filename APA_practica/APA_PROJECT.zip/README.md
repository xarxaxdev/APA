# Pokemon dataset studying
This is a project done in the APA subject in FIB  (UPC Barcelona).

To see the whole process run the NEEDED steps for execution.

### preprocessing.r
This file is the basic preprocessing we did before visualizing the data.
A couple variables were deleted since we didn't find them useful.
We converted 'type1' and 'type2' to dummy variables to better represent our dataset.
We converted 'egg_group1' and 'egg_group2' to dummy variables to better represent our dataset.
Ability 'None' was added for the abilities that were NAs.

### splitting.r
This file is necessary for create our learning data and testing data. Since our models are in
two separated files it's a good idea to create and save our sets separately.

### linear&SVM.r
We fit the linear regressi�n and the SVMs (Linear SVM, Quadratic SVM and RBF SVM).

### MLP.r
We fit an MLP using keras, the state of the art library for deep learning.
