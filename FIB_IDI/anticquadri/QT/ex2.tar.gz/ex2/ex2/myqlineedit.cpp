#include "myqlineedit.h"

QString textfrom ="";
QString textto="";
int cont=0;

MyQLineEdit::MyQLineEdit(QWidget *parent) :
    QLineEdit(parent)
{
}

void MyQLineEdit::cambio()
{
    QString temp = this->text();
    cont = temp.count(textfrom);
    temp = temp.replace(textfrom,textto);
    setText(temp);
    emit changedisplay(cont);
}

void MyQLineEdit::saveto(QString to)
{
    textto = to;
}

void MyQLineEdit::savefrom(QString from)
{
    textfrom = from;
}
