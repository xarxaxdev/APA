#ifndef MYQLINEEDIT_H
#define MYQLINEEDIT_H

#include <QLineEdit>

class MyQLineEdit : public QLineEdit
{
    Q_OBJECT
public:
    explicit MyQLineEdit(QWidget *parent = 0);
    
signals:
    void changedisplay(int);
public slots:
    
    void cambio();
    void saveto(QString);
    void savefrom(QString);

};

#endif // MYQLINEEDIT_H
